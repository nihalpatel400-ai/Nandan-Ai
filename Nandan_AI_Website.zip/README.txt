NANDAN AI website preview

1. Open index.html in a browser to preview the website.
2. This version has a responsive chat interface and demo replies.
3. It is NOT connected to a real AI model yet.
4. To add real AI responses, create a small backend server and connect an AI API from the backend.
   Do not put a private API key directly in index.html or browser JavaScript.
5. Upload the website files to a static hosting provider to publish the frontend.

Files:
- index.html: complete website preview in one file
